#ifndef CONSTANT_H
#define CONSTANT_H

#define CLUSTER_SIZE 5000

#define FAT_UNUSED __INT_MAX__ - 1
#define FAT_FILE_END __INT_MAX__ - 2
#define FAT_BAD_CLUSTER __INT_MAX__ - 3

#endif